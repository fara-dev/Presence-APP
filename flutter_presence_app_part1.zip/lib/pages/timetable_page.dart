import 'package:flutter/material.dart';

class TimetablePage extends StatefulWidget {
  const TimetablePage({super.key});

  @override
  State<TimetablePage> createState() => _TimetablePageState();
}

class _TimetablePageState extends State<TimetablePage> {
  String selectedDay = 'Mardi';

  final Map<String, List<Map<String, dynamic>>> timetable = {
    'Lundi': [],
    'Mardi': [
      {'time': '10H', 'activity': 'Robotique', 'color': Colors.green},
      {'time': '12H', 'activity': 'AI Club', 'color': Colors.blue},
      {'time': '14H', 'activity': 'Coding', 'color': Colors.orange},
      {'time': '16H', 'activity': 'Design', 'color': Colors.purple},
    ],
    'Mercredi': [],
    'Jeudi': [],
  };

  @override
  Widget build(BuildContext context) {
    final sessions = timetable[selectedDay] ?? [];
    return Scaffold(
      appBar: AppBar(title: const Text("Emploi du Temps")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            DropdownButton<String>(
              value: selectedDay,
              isExpanded: true,
              items: timetable.keys
                  .map((day) => DropdownMenuItem(
                        value: day,
                        child: Text(day),
                      ))
                  .toList(),
              onChanged: (value) => setState(() => selectedDay = value!),
            ),
            const SizedBox(height: 16),
            if (sessions.isEmpty)
              const Text("Aucune session"),
            ...sessions.map((session) => Container(
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: session['color'].withOpacity(0.1),
                    border: Border.all(color: session['color']),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(session['time'], style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text(session['activity']),
                    ],
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
